# test
test



测试测试测试测试
<<<<<<< HEAD
<<<<<<< Updated upstream
=======
=======
>>>>>>> localbranch



使用"git commit -v"命令

<<<<<<< HEAD
测试“git branch -set-upstream-to localbranch master”命令 

测试“git push origin localbranch”命令会在远程服务器端新建localbranch分支
>>>>>>> Stashed changes
=======
测试“git branch -set-upstream-to localbranch master”命令
>>>>>>> localbranch


insert test


local
